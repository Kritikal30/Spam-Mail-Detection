# Malicious-Mail-Detection
This app will detect malicious mails.
